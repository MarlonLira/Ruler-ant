# Controle_Estoque_CompraVenda-.Net-Camadas
Sistema de Controle de Estoque Compra e Venda (C# .NET-Camadas)

Em construção!!!

Objetos tratados no Sistema.

-Pessoa, Pessoa Física e Pessoa Jurídica.

-Filial, Cliente e Fornecedor.

-Produto, Estoque, Estoque Reservado, Estoque Movimentado.

-Pedido, Item do Pedido.

Tecnologias e Ferramentas

-SQL Server.

-Visual Studio 2013.

-C# .NET.
