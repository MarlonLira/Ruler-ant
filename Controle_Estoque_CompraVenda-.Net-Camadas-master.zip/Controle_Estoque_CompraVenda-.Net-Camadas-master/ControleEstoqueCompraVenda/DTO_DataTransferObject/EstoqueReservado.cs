﻿
namespace DTO_DataTransferObject
{
    public class EstoqueReservado
    {
        public Filial Filial { get; set; }
        public Produto Produto { get; set; }
        public int Quantidade { get; set; }
    }
}
