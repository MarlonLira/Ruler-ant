﻿
namespace DTO_DataTransferObject
{
    public class Fornecedor
    {
        public Pessoa Pessoa { get; set; }
    }
}
