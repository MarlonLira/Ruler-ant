﻿using System.Collections.Generic;

namespace DTO_DataTransferObject
{
    public class EstoqueColetion : List<Estoque>
    {
    }
}
