﻿
namespace DTO_DataTransferObject
{
    public class Cliente
    {
        public Pessoa Pessoa { get; set; }
    }
}
