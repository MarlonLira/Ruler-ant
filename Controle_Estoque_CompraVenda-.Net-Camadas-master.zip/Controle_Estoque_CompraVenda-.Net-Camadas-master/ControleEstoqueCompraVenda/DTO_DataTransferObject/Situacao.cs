﻿
namespace DTO_DataTransferObject
{
    public class Situacao
    {
        public int IDSituacao { get; set; }
        public string Descricao { get; set; }
    }
}
