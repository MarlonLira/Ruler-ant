﻿
namespace DTO_DataTransferObject
{
    public class Estoque
    {
        public Filial Filial { get; set; }
        public Produto Produto { get; set; }
        public int Quantidade { get; set; }
    }
}
