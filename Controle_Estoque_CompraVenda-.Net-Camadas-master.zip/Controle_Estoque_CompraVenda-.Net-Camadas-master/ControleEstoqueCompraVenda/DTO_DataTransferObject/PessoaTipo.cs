﻿
namespace DTO_DataTransferObject
{
    public class PessoaTipo
    {
        public int IDPessoaTipo { get; set; }
        public string Descricao { get; set; }
    }
}
