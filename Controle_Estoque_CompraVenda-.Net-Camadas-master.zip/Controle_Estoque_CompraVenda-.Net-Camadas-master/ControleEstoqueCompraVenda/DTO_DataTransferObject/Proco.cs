﻿
namespace DTO_DataTransferObject
{
    public class Proco
    {
        public Produto Produto { get; set; }
        public decimal Valor { get; set; }
    }
}
