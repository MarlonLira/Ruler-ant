﻿using System.Collections.Generic;

namespace DTO_DataTransferObject
{
    public class FilialColetion : List<Filial>
    {
    }
}
