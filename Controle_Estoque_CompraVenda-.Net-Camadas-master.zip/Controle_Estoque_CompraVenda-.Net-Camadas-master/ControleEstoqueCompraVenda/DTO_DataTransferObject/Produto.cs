﻿
namespace DTO_DataTransferObject
{
    public class Produto
    {
        public int IDProduto { get; set; }
        public string  Descricao { get; set; }
    }
}
