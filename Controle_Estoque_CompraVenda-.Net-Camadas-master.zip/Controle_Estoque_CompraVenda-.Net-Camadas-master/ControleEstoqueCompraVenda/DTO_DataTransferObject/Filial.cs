﻿
namespace DTO_DataTransferObject
{
    public class Filial
    {
        public Pessoa Pessoa { get; set; }
    }
}
