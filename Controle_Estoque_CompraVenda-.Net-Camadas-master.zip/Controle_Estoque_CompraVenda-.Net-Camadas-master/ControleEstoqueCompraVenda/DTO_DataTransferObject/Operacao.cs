﻿
namespace DTO_DataTransferObject
{
    public class Operacao
    {
        public int IDOperacao { get; set; }
        public string Descricao { get; set; }
    }
}
