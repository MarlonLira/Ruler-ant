﻿using System.Collections.Generic;

namespace DTO_DataTransferObject
{
    public class PessoaFisicaColetion : List<PessoaFisica>
    {
    }
}
