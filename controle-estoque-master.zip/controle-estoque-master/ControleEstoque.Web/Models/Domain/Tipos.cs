﻿namespace ControleEstoque.Web.Models
{
    public enum TipoPessoa : int
    {
        Fisica = 1,
        Juridica
    }
}