﻿namespace ControleEstoque.Web.Models
{
    public class InventarioComDiferencaViewModel
    {
        public string Id { get; set; }
        public string Nome { get; set; }
    }
}