﻿namespace ControleEstoque.Web.Models
{
    public class LancamentoPerdaViewModel
    {
        public int Id { get; set; }
        public string Motivo { get; set; }
    }
}